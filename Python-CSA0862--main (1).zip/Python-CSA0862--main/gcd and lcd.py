n1=int(input("enter number"))
n2=int(input("enter number"))
if n1>n2:
    n1,n2=n2,n1
for i in range(1,n1+1):
    if n1%i==0 and n2%i==0:
        gcd=i
lcm=(n1*n2)//gcd
print(gcd)
print(lcm)
