n1=int(input("enter a number:\n"))
n2=int(input("enter a number: \n"))
n3=int(input("eneter a number:\n"))
if(n1>n2 and n1>n3):
    print("n1 is greater")
elif(n2>n1 and n2>n3):
    print("n2 is greater")
else:
    print("n3 is greater")
