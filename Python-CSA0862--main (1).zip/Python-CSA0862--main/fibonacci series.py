n=int(input("enter no of digits: "))
a=0
b=1
print(a,b,sep='\n')
for i in range(2,n):
    c=a+b
    print(c)
    a=b
    b=c
