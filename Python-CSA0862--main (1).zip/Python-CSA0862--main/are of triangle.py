l=int(input("enter length"))
b=int(input("enter breadth"))
a=0.5*l*b
print(a)
