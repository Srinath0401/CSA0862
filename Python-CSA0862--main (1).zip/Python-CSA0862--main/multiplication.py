n=int(input("enter a number:\n"))
for i in range(1,11):
    print(i,"*",n,"=",i*n)
