n=int(input("enter a number:\n"))
if(n<=15 and n>=10):
    print("dwarf")
elif(n<=30 and n>=16):
    print("average")
elif(n>=31):
    print("tall")
