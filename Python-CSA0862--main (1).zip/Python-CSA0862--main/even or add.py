n=int(input("enter a number \n"))
if(n%2==0):
    print("even")
else:
    print("odd")
