n=int(input("enter a number:\n"))
if(n<0):
    print("negative")
elif(n>0):
    print("positive")
else:
    print("error") 
