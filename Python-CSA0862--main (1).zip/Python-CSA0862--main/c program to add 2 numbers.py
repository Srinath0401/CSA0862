a=input("enter a binary number")
b=input("enter a binary number")
sum = bin(int(a, 2) + int(b, 2))
print(sum[2:])
