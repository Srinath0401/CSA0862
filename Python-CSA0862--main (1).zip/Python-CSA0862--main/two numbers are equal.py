n=int(input("enter a number"))
b=int(input("enter a number"))
if(n==b):
       print("equal")
else:
       print("not equal")
