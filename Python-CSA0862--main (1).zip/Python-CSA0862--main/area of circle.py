r=int(input("enter radius"))
a=3.14*r*r
print(a)
